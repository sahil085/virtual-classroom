package main;

import org.springframework.stereotype.Component;

/**
 * Created by user on 7/4/2017.
 */
@Component
public class Employee {

}
