package main.aspect;

/**
 * Created by user on 7/4/2017.
 */
@Asp
public class Operation {
}
