package main.service;

import org.springframework.stereotype.Service;

/**
 * Created by user on 7/4/2017.
 */
@Service
public interface EmployeeService {
    void displayName();
    void dispalyAge();
}
