package controller;

import model.insertblog;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Created by user on 6/27/2017.
 */
@WebServlet("/addblog")
public class addblog extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       HttpSession ss=request.getSession();

        try {
            PrintWriter out=response.getWriter();
            if(insertblog.insertblog(request.getParameter("val"),(String)ss.getAttribute("uname")))
            {

                out.write("blog added successfully");
            }
            else
            {
                out.write("blog not added <br> please try after sometime");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


}
