package controller;

import model.authentication;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by user on 6/27/2017.
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        HttpSession ss=request.getSession();
        if(ss.getAttribute("uname")==null) {
            authentication a = new authentication();
            PrintWriter out = response.getWriter();

            response.setContentType("text/html");
            try {

                if (a.authenticate(request.getParameter("name"), request.getParameter("pass"))) {

                    ss.setAttribute("uname", request.getParameter("name"));
                    System.out.println("login");

                    response.sendRedirect("http://localhost:8080/blogs.html");
                } else {
                    out.print("lj;kk;");
//                out.write("INVALID PASSWORD OR USERNAME");
                    RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                    rd.include(request, response);

                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else
        {
            response.sendRedirect("http://localhost:8080/blogs.html");
        }
    }

//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//
//    }
}
