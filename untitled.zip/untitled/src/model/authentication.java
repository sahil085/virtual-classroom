package model;

/**
 * Created by user on 6/27/2017.
 */
import javax.servlet.http.HttpSession;
import java.sql.*;
public class authentication {
public static Connection con;
static
{

    try{
        Class.forName("com.mysql.jdbc.Driver");
       con =DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/sahil","root","root");

    }
    catch(Exception e){ System.out.println(e);}
}
public static boolean authenticate(String uname,String password)throws SQLException
{
    String name=uname;
    String pass=password;
    PreparedStatement ps=con.prepareStatement("SELECT username,userpassword from user where username=? && userpassword=? ");
    ps.setString(1,name);
    ps.setString(2,pass);
    ResultSet rs=ps.executeQuery();
    if(rs.next())
    {
        return true;
    }
    else {
        return false;
    }
}
    public static void main(String[] args)throws SQLException {



    }
}
