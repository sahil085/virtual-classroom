package model;

import javax.servlet.http.HttpSession;
import java.sql.*;

/**
 * Created by user on 6/27/2017.
 */
public class insertblog {
    public static boolean insertblog(String blog,String uname)throws SQLException
    {
        PreparedStatement ps1=authentication.con.prepareStatement("select max(blogid) from blogs");
        ResultSet rs1=ps1.executeQuery();
        int max=0;
        if(rs1.next())
        {
            max=rs1.getInt(1);

        }
        PreparedStatement ps=authentication.con.prepareStatement("insert into blogs values(?,?,?)");
        ps.setInt(1,max+1);
        ps.setString(2,uname);
        ps.setString(3,blog);
        if(ps.executeUpdate()>0)
        {
            return true;
        }
        else
        {
            return false;
        }


    }
}
