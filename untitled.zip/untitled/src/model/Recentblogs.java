package model;

/**
 * Created by user on 6/28/2017.
 */
public class Recentblogs {

}
