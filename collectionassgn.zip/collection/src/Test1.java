
import java.util.*;

public class Test1 {
    public static void main(String[] args) {
        List<Float> al =new ArrayList();
        al.add(2.4f);
        al.add(3.4f);
        al.add(4.5f);
        al.add(12.5f);
        al.add(45.5f);
        Iterator<Float> it=al.iterator();
         String sum="";
         float s=0.0f;
        while(it.hasNext())
        {        
          s=s+it.next();;
        }
        System.out.println("sum "+s);    
}
}
