public class Test7 {
   static Integer[] stk;
   static int size;
   static int top=0,min=9999;
    public static void fixsize(int size)
    {
        stk=new Integer[size];
        Test7.size=size;
    }
    public static void push(Object o)
    {
        if(!isfull())
        {
        Integer in=new Integer((int)o);
        stk[top]=in;
        top++;
        }
    }
    public static void pop()
    {
     if(!isempty())
     {
       stk[top-1]=null;
       top--;
     }
    }
    public static void showstack()
    {
        if(isempty())
        {
            System.out.println("stack is empty");
        }
        else
        {
        for(int i=0;i<top;i++)
        {
            System.out.println(stk[i]);
        }
        }
    }
    public static boolean isempty()
    {
        if(stk[0]==null)
        {
             return true;
        }
        else
        {
             return false;
        }   
    }
    public static boolean isfull()
    {
        if(top==size+1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public static int getmin()
    {
    
        return min;
    }
    public static void min()
    {
           
       for(int i=0;i<stk.length;i++)
       {
           if(stk[i]!=null)
           {
           if(min>stk[i])
           {
               min=stk[i];
               
           }
           }
       }
       
    }
    public static void main(String[] args) {
        fixsize(5);
        push(11);
        min();
        push(2);
        min();
        push(3);
        min();
         System.out.println(" ALL STACK ELEMENTS ");
        showstack();
        System.out.println("ELEMENT AFTER POP OPERATION");
        pop();
        min();
        showstack();
        System.out.println("MINIMUM ELEMENT IN STACK");
        System.out.println(getmin());
        System.out.println("--------------------------------------");
        
}
}
