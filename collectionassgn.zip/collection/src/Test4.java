import java.util.*;
public class Test4{
    double salary=0.0,age=0.0;
    String name="";
    static Test4 e1,e2,e3;
    public Test4(double age,double salary,String name) {
        this.age=age;
        this.salary=salary;
        this.name=name;
    }
    
    public static void main(String[] args) {
        ArrayList al=new ArrayList();
        e1=new Test4(30.3,12000.40,"sahil");
        e2=new Test4(34.3,42000.40,"krishna");
        e3=new Test4(40.3,32000.40,"radha");
     al.add(e1);
     al.add(e2);
     al.add(e3);
        Collections.sort(al,new salary());
        for(int i=0;i<al.size();i++)
        {
            Test4 e=(Test4)al.get(i);
            
            System.out.println("sorting on the basis of salary "+e.salary);
        }
}
}
class salary implements Comparator<Test4>
{

    @Override
    public int compare(Test4 o1, Test4 o2) {
        int f=-1;
         if(o1.salary>o2.salary)
         {  
             return 1;
         }
         else
         {
             return -1;
         }
        
    }   
}



