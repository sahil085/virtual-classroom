
import java.util.*;

public class Test2 {
    public static long unichar(String s)
    {
          HashMap<Character,Integer> hs=new HashMap();
        long uni=0;
        boolean flag=false;
        s=s.replaceAll(" ","");
      for(int i=0;i<s.length();i++)
      {
          if(hs.containsKey(s.charAt(i)))
          {  
//              System.out.println(s.charAt(i));
               
               hs.put(s.charAt(i),hs.get(s.charAt(i))+1);
          }
          else
          {
              hs.put(s.charAt(i),1);  
          }
      }
     Iterator<Character> it=hs.keySet().iterator();
     while(it.hasNext())
     {
         Character chh=it.next();
         if(hs.get(chh).equals(1))
         {
            uni++; 
         }
     }
      return uni;
}
    public static void main(String[] args) {
        System.out.println("stream of unique character is "+unichar("abcca"));
}
}
