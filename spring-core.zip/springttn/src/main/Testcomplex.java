package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by user on 6/29/2017.
 */
public class Testcomplex {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("resources/beans.xml");
        Complex cm=ctx.getBean("ComplexBean",Complex.class);
        cm.Displaylist();
        cm.Displaymap();
        cm.Displayset();
    }
}
