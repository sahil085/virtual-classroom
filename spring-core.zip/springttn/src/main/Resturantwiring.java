package main;

import org.springframework.beans.factory.annotation.Required;

/**
 * Created by user on 6/29/2017.
 */
public class Resturantwiring
{


    /// to check scope ////
    String resturantname;
Hotdrinkwiring teaname;
Hotdrinkwiring teatype;
Hotdrinkwiring teacont;
Hotdrinkwiring requiredhotdrink;



    public Resturantwiring(){}
public Resturantwiring(teawiring teacont)
{
    this.teacont=teacont;
}
    public Hotdrinkwiring getRequiredhotdrink() {
        return requiredhotdrink;
    }
   @Required
    public void setRequiredhotdrink(Hotdrinkwiring requiredhotdrink) {
        this.requiredhotdrink = requiredhotdrink;
    }
    public String getResturantname() {
        return resturantname;
    }

    public void setResturantname(String resturantname) {
        this.resturantname = resturantname;
    }
    public Hotdrinkwiring getTeaname() {
        return teaname;
    }

    public void setTeaname(Hotdrinkwiring teaname) {
        this.teaname = teaname;
    }

    public Hotdrinkwiring getTeatype() {
        return teatype;
    }

    public void setTeatype(Hotdrinkwiring teatype) {
        this.teatype = teatype;
    }
}
