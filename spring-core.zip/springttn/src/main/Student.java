package main;

/**
 * Created by user on 6/29/2017.
 */
public class Student {
    String sname;

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }
}
