package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by user on 6/29/2017.
 */
public class Testannotationfield {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("resources/beans.xml");
        Resturantannotaionfield rf=ctx.getBean("annotationwiringonfield",Resturantannotaionfield.class);
        String s=rf.getT().preparedhotdrink();
        System.out.println(s);
    }
}
