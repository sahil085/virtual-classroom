package main;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by user on 6/29/2017.
 */
public class Resturantannotaionfield {
    @Autowired
    Tea t;

    public Tea getT() {
        return t;
    }

    public void setT(Tea t) {
        this.t = t;
    }
}
