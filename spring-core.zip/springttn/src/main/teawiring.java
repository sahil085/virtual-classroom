package main;

/**
 * Created by user on 6/29/2017.
 */
public class teawiring implements Hotdrinkwiring {

    @Override
    public void preparedhotdrink() {
        System.out.println("teawiring");
    }
}
