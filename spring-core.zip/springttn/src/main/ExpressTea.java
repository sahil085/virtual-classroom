package main;

/**
 * Created by user on 6/29/2017.
 */
public class ExpressTea implements HotDrink {
    @Override
    public String preparedhotdrink() {
        return "exp-tea";
    }
}
