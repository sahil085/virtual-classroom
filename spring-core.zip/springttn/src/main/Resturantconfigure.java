package main;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;

/**
 * Created by user on 6/29/2017.
 */
@Component
@Repository
@Controller
public class Resturantconfigure {
}
