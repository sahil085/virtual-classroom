package main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by user on 6/29/2017.
 */
public class Testtea {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("resources/beans.xml");
        Resturant r=ctx.getBean("tearesturant",Resturant.class);
            HotDrink hd=r.getHotDrink();
        Resturant r2=ctx.getBean("expresturant",Resturant.class);
        HotDrink exp=r2.getHotDrink();

        System.out.println("calling preparedhotdrink by hotdrink \n" +hd.preparedhotdrink());
        System.out.println(exp.preparedhotdrink());
    }
}
