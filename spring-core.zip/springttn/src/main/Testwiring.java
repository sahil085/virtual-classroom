package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by user on 6/29/2017.
 */
public class Testwiring {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("resources/wiring.xml");
//        Resturantwiring r=ctx.getBean("resturantbyname",Resturantwiring.class);
//        r.getTeaname().preparedhotdrink();
//        Resturantwiring rt=ctx.getBean("resturantbytype",Resturantwiring.class);
//        rt.getTeaname().preparedhotdrink();
        Resturantwiring rc=ctx.getBean("resturantbyconstructor",Resturantwiring.class);
        rc.getTeaname().preparedhotdrink();

    }
}
