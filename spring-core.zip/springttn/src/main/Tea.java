package main;

/**
 * Created by user on 6/29/2017.
 */
public class Tea implements HotDrink {
    @Override
    public String preparedhotdrink() {

return "tea";
    }
}
