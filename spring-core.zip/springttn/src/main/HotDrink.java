package main;

/**
 * Created by user on 6/29/2017.
 */
public interface HotDrink {
    abstract String preparedhotdrink();
}
