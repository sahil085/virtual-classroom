package main;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by user on 6/29/2017.
 */
public class Complex {

    List l;
    Set set;
    Map<String,String> m;

    public List getL() {
        return l;
    }

    public void setL(List l) {
        this.l = l;
    }

    public Set getSet() {
        return set;
    }

    public void setSet(Set set) {
        this.set = set;
    }

    public Map getM() {
        return m;
    }

    public void setM(Map m) {
        this.m = m;
    }
    void Displaylist()
    {
        Iterator itr=l.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next().toString());
        }
    }
    void Displaymap()
    {
        Set<Map.Entry<String,String>> s= m.entrySet();
        Iterator it=s.iterator();
        while (it.hasNext())
        {
            Map.Entry<String,String> me= (Map.Entry<String, String>) it.next();
            System.out.println(me.getKey()+" "+me.getValue());
        }
    }
    void Displayset()
    {
        Iterator ir= set.iterator();
        while(ir.hasNext())
        {
            System.out.println(ir.next());
        }

    }

}
