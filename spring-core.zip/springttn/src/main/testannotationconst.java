package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by user on 6/29/2017.
 */
public class testannotationconst {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("resources/beans.xml");
        Resturantannotationconst rc=ctx.getBean("annotaionwiringonconst",Resturantannotationconst.class);
        String c=rc.t.preparedhotdrink();
        System.out.println(c);
    }
}
