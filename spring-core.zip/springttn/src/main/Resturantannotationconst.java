package main;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by user on 6/29/2017.
 */
public class Resturantannotationconst {

    Tea t;

    @Autowired
    Resturantannotationconst(Tea t)
    {
        this.t=t;
    }
}
