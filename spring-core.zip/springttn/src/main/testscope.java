package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by user on 6/29/2017.
 */
public class testscope {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("resources/wiring.xml");
        Resturantwiring rw=ctx.getBean("tearesturant",Resturantwiring.class);

        System.out.println(" object created first time and value is injected by xml file");
        System.out.println(rw.getResturantname());

        System.out.println(" object created second time and value is set by me is -- > bikanervala");
        rw.setResturantname("bikanervala");
        Resturantwiring rw2=ctx.getBean("tearesturant",Resturantwiring.class);
        System.out.println(rw2.getResturantname());


        System.out.println("in second object value is injected again by xml file , it means new object is created when we call get bean method");


        System.out.println("@getRequiredhotdrink annotaion in setter method of hotdrink \n");
        rw2.getRequiredhotdrink().preparedhotdrink();
    }
}
