package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by user on 6/29/2017.
 */
public class testannotations
{
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("resources/beans.xml");

        resturantannotationwiring rt=ctx.getBean("annotationwiring",resturantannotationwiring.class);

        String s=rt.getT().preparedhotdrink();
        System.out.println(s);
    }
}
