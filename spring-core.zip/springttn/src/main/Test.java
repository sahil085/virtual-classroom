package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import javax.annotation.PostConstruct;
import javax.annotation.Resources;

/**
 * Created by user on 6/29/2017.
 */

public class Test {

    public static void main(String[] args) {
        ApplicationContext context=new ClassPathXmlApplicationContext("resources/beans.xml");
        employee e=context.getBean("emp",employee.class);
        System.out.println(e.getName()+" "+e.getStu().getSname());

    }
}
