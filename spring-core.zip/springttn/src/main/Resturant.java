package main;

/**
 * Created by user on 6/29/2017.
 */
public class Resturant {

    HotDrink hotDrink;
    Tea t;

    public HotDrink getHotDrink() {
        return hotDrink;
    }

    public void setHotDrink(HotDrink hotDrink) {
        this.hotDrink = hotDrink;
    }

    public Tea getT() {
        return t;
    }

    public void setT(Tea t) {
        this.t = t;
    }
}
