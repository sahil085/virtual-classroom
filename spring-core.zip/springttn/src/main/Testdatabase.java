package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by user on 6/29/2017.
 */
public class Testdatabase {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("resources/beans.xml");
        Database d=(Database)ctx.getBean("dbase");
        System.out.println("name of database "+ d.getName()+" port "+d.getPort());
    }
}
