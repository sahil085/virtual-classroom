package main;

/**
 * Created by user on 6/29/2017.
 */
public class Expresswiring implements Hotdrinkwiring  {

    @Override
    public void preparedhotdrink() {
        System.out.println("express tea wiring");
    }
}
