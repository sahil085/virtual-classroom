package test;

import beans.Address;
import beans.Author14;
import beans.Author14;
import beans.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 qtn 10 and 11 are same
 */
public class Main14 {
    static Configuration cfg;
    static  SessionFactory sf;
    static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate14.cfg.xml");
        sf =cfg.buildSessionFactory();
        ss=sf.openSession();
    }

    public static void retrieve() {
        List<Author14> ll = ss.createQuery("from Author14 ").list();

        for (Author14 aa : ll) {
            System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname()+" dob "+aa.getDob());
        }

    }
    public static void main(String[] args) {

        Author14 au=new Author14();
        Book b=new Book();
        Book b1=new Book();
        b.setBookname("java book");
        b1.setBookname("c book");
        au.setB(b);
//        au.setB(b1);
        au.setAge(22);
        au.setFirstname("ayushi");
        au.setLastname("sahil");
        au.setDob(new Date());
        ss.beginTransaction();
        ss.save(au);
        ss.save(b);
//        ss.save(b1);
        ss.getTransaction().commit();
        retrieve();
        ss.close();

    }
}
