package test;

import beans.Author;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.Date;
import java.util.List;

/**
 * Created by user on 6/28/2017.
 */
public class Main4 {
    static Configuration cfg;
    static  SessionFactory sf;
    static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate4.cfg.xml");
        sf =cfg.buildSessionFactory();
        ss=sf.openSession();
    }
    public static Session getsession()
    {

        return ss;
    }
    public static void retrieve() {
        List<Author> ll = ss.createQuery("from Author ").list();

        for (Author aa : ll) {
            System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname()+" dob "+aa.getDob());
        }

    }
    public static void main(String[] args) {

        Author a1=new Author();
       Author a2=new Author();
       Author a3=new Author();
       Author a4=new Author();
        a1.setAge(22);
        a1.setFirstname("ayushi");
        a1.setLastname("sahil");
        a1.setDob(new Date());

        a2.setAge(22);
        a2.setFirstname("ayushi");
        a2.setLastname("sahil");
        a2.setDob(new Date());

        a3.setAge(22);
        a3.setFirstname("ayushi");
        a3.setLastname("sahil");
        a3.setDob(new Date());

        a4.setAge(22);
        a4.setFirstname("ayushi");
        a4.setLastname("sahil");
        a4.setDob(new Date());
        ss.beginTransaction();
        ss.save(a1);
        ss.save(a2);
        ss.save(a3);
        ss.save(a4);
        ss.getTransaction().commit();
        retrieve();

        ss.close();
        sf.close();
    }
}
