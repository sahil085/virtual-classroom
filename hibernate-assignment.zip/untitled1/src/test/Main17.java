package test;

import beans.*;
import beans.Author17;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.*;

/**
 qtn 10 and 11 are same
 */
public class Main17 {
    static Configuration cfg;
    static  SessionFactory sf;
    static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate17.cfg.xml");
        sf =cfg.buildSessionFactory();
        ss=sf.openSession();
    }

    public static void retrieve() {
        List<Author17> ll = ss.createQuery("from Author17 ").list();

        for (Author17 aa : ll) {
            System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname()+" dob "+aa.getDob());
        }

    }
    public static void main(String[] args) {

        ///////// Many to Many ///////////
        ss.beginTransaction();
 Set<Book17> bookset=new HashSet();
        Author17 au=new Author17();
        au.setAge(22);
        au.setDob(new Date());
        au.setFirstname("shubham");
        au.setLastname("gupta");

        Author17 au1=new Author17();
        au1.setAge(21);
        au1.setDob(new Date());
        au1.setFirstname("shubh");
        au1.setLastname("kumar");


        Book17 b=new Book17();
        Book17 b1=new Book17();

        b.setBookname("java");
        b1.setBookname("c");
        bookset.add(b);
        bookset.add(b1);
        au1.setB(bookset);
        au.setB(bookset);

   ss.save(au);
   ss.save(au1);

        ss.getTransaction().commit();
        retrieve();
        ss.close();

    }
}
