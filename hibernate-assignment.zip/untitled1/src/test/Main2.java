package test;

import beans.Author;
import javafx.application.Application;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.management.Query;
import java.util.Date;
import java.util.List;

/**
 * Created by user on 6/29/2017.
 */
public class Main2 {
    static Configuration cfg;
    static SessionFactory sf;
    static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate3.cfg.xml");
        sf =cfg.buildSessionFactory();
        ss=sf.openSession();
    }

    public static void retrieve() {
        try {
            List<Author> ll = ss.createQuery("from Author ").list();

            for (Author aa : ll) {
                System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname() + " dob " + aa.getDob());
            }
        }
        catch (Exception e)
        {
            System.out.println(e);
        }


    }
    public static void update()
    {
        try {

            ss.beginTransaction();
            Author q = ss.get(Author.class, 1);
            q.setFirstname("radha");
            q.setLastname("krishna");
            q.setAge(22);
            q.setDob(new Date());
            ss.saveOrUpdate(q);
            ss.getTransaction().commit();
            System.out.println("data updated");
        }
        catch (Exception e) {
            System.out.println("error "+e);
        }


    }
    public static void delete()
    {
        try {

            ss.beginTransaction();
            Author q = ss.get(Author.class, 1);
            ss.delete(q);
            ss.getTransaction().commit();
            System.out.println("data deleted");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }

    }
    public static void main(String[] args) {
        try {
            ss.beginTransaction();
            Author au = new Author();
            au.setDob(new Date());
            au.setFirstname("sahil");
            au.setLastname("verma");
            au.setAge(20);
            Author au1 = new Author();
            au1.setDob(new Date());
            au1.setFirstname("sahil");
            au1.setLastname("verma");
            au1.setAge(20);
            ss.save(au);
            ss.save(au1);
            ss.getTransaction().commit();
            System.out.println(" data added successfully");
            retrieve();
          update();
        delete();

        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        finally {
            ss.close();
            sf.close();
        }
    }
}
