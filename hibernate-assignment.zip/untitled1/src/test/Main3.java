package test;

import beans.Author;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.Date;
import java.util.List;

/**
 * Created by user on 6/28/2017.
 */
public class Main3 {
    static Configuration cfg;
   static  SessionFactory sf;
   static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate3.cfg.xml");
       sf =cfg.buildSessionFactory();
       ss=sf.openSession();
    }
    public static Session getsession()
    {

        return ss;
    }
    public static void retrieve() {
        List<Author> ll = ss.createQuery("from Author ").list();

        for (Author aa : ll) {
            System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname()+" dob "+aa.getDob());
        }

    }
    public static void main(String[] args) {

        Author au=new Author();

        au.setAge(22);
        au.setFirstname("ayushi");
        au.setLastname("sahil");
        au.setDob(new Date());
        ss.beginTransaction();
        ss.save(au);       ss.getTransaction().commit();
        retrieve();
        ss.close();
    }
}
