package test;

import beans.Address;
import beans.Author10;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.Date;
import java.util.List;

/**
 qtn 10 and 11 are same
 */
public class Main10 {
    static Configuration cfg;
    static  SessionFactory sf;
    static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate10.cfg.xml");
        sf =cfg.buildSessionFactory();
        ss=sf.openSession();
    }

    public static void retrieve() {
        List<Author10> ll = ss.createQuery("from Author10").list();

        for (Author10 aa : ll) {
            System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname()+" dob "+aa.getDob());
        }

    }
    public static void main(String[] args) {

        Author10 au=new Author10();
        Address ad=new Address();
        ad.setLocation("delhi");
        ad.setState("delhi");
        ad.setStreetnumber(24);
        au.setAddress(ad);
        au.setAge(22);
        au.setFirstname("ayushi");
        au.setLastname("sahil");
        au.setDob(new Date());
        ss.beginTransaction();
        ss.save(au);       ss.getTransaction().commit();
        retrieve();

        ss.close();

    }
}
