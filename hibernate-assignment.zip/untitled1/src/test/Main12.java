package test;

import beans.Address;
import beans.Author12;
import beans.Author12;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 qtn 10 and 11 are same
 */
public class Main12 {
    static Configuration cfg;
    static  SessionFactory sf;
    static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate12.cfg.xml");
        sf =cfg.buildSessionFactory();
        ss=sf.openSession();
    }

    public static void retrieve() {
        List<Author12> ll = ss.createQuery("from Author12").list();

        for (Author12 aa : ll) {
            System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname()+" dob "+aa.getDob());
        }

    }
    public static void main(String[] args) {

        Author12 au=new Author12();
       List<String> subject1=new ArrayList();
       subject1.add("maths");
       subject1.add("english");
       subject1.add("chemistry");
       au.setSubjects(subject1);
        au.setAge(22);
        au.setFirstname("ayushi");
        au.setLastname("sahil");
        au.setDob(new Date());
        ss.beginTransaction();
        ss.save(au);       ss.getTransaction().commit();
        retrieve();

        ss.close();

    }
}
