package test;

import beans.*;
import beans.Author16b;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.*;

/**
 qtn 10 and 11 are same
 */
public class Main16b {
    static Configuration cfg;
    static  SessionFactory sf;
    static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate16b.cfg.xml");
        sf =cfg.buildSessionFactory();
        ss=sf.openSession();
    }

    public static void retrieve() {
        List<Author16b> ll = ss.createQuery("from Author16b ").list();

        for (Author16b aa : ll) {
            System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname()+" dob "+aa.getDob());
        }

    }
    public static void main(String[] args) {


        //////// one to many bi-directional /////////
    ss.beginTransaction();
     Author16b au=new Author16b();
     au.setFirstname("radha");
     au.setAge(22);
     au.setDob(new Date());
     au.setLastname("krishna");

//        List<Book16b> list=new ArrayList<>();
        Set<Book16b> set=new HashSet<Book16b>();
     Book16b book=new Book16b();
     book.setBookname("geeta");
     book.setAuthor(au);

     set.add(book);

     Book16b book1=new Book16b();
        book1.setBookname("bhakti rasamrit");
        book1.setAuthor(au);
        set.add(book1);
     au.setB(set);

     ss.save(au);
        ss.getTransaction().commit();
        retrieve();
        ss.close();

    }
}
