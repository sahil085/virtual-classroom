package test;

import beans.*;
import beans.Author16;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 qtn 10 and 11 are same
 */
public class Main16 {
    static Configuration cfg;
    static  SessionFactory sf;
    static Session ss;
    static
    {
        cfg=new Configuration().configure("hibernate16.cfg.xml");
        sf =cfg.buildSessionFactory();
        ss=sf.openSession();
    }

    public static void retrieve() {
        List<Author16> ll = ss.createQuery("from Author16 ").list();

        for (Author16 aa : ll) {
            System.out.println(" age " + aa.getAge() + " firstname " + aa.getFirstname() + " last name " + aa.getLastname()+" dob "+aa.getDob());
        }

    }
    public static void main(String[] args) {

        ///////// one to many uni-directional ///////////


       List<Book16> list=new ArrayList<>();
       list.add(new Book16("java book"));
       list.add(new Book16("c book"));
        Author16 au=new Author16(list);
        au.setAge(22);
        au.setFirstname("ayushi");
        au.setLastname("sahil");
        au.setDob(new Date());
        ss.beginTransaction();
        ss.save(au);

        ss.getTransaction().commit();
        retrieve();
        ss.close();

    }
}
