package beans;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by user on 6/28/2017.
 */
@Entity

public class Author16 {
    @Id
    @GeneratedValue
    private int id;
    private int age;
    @OneToMany(cascade = CascadeType.ALL)
   private List<Book16> b=new ArrayList<>();

    private String firstname;

    private String lastname;

    private Date dob;
    private String bookname;

    public Author16(){}
    public Author16(List<Book16> b)
    {
    this.b=b;
    }

    public List<Book16> getB() {
        return b;
    }

    public void setB(List<Book16> b) {
        this.b = b;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
