package beans;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by user on 6/28/2017.
 */
@Entity
public class Author8 {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
  private int age;
    private String firstname;

    private String lastname;

   @Temporal(TemporalType.DATE)
    private Date dob;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
