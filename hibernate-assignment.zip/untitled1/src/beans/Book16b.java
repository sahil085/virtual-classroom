package beans;

import org.hibernate.engine.internal.Cascade;

import javax.annotation.Generated;
import javax.persistence.*;

/**
 * Created by user on 6/28/2017.
 */
@Entity
public class Book16b {
    @Id
    @GeneratedValue(strategy =GenerationType.AUTO )
    private int bid;
    private String bookname;
    @ManyToOne
    private Author16b author;

    public Author16b getAuthor() {
        return author;
    }

    public void setAuthor(Author16b author) {
        this.author = author;
    }

    public Book16b(){}
    public Book16b(String bookname)
    {
        this.bookname=bookname;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }
}
