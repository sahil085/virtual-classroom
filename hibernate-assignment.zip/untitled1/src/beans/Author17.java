package beans;

import javax.persistence.*;
import java.util.*;

/**
 * Created by user on 6/28/2017.
 */
@Entity

public class Author17 {
    @Id
    @GeneratedValue
    private int id;
    private int age;
    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = ("Author_Book"), joinColumns = { @JoinColumn(name = ("id")) }, inverseJoinColumns = { @JoinColumn(name = ("bid") )})
    private Set<Book17> b = new HashSet<>();

    private String firstname;

    private String lastname;

    private Date dob;


    public Author17() {
    }

    public Set<Book17> getB() {
        return b;
    }

    public void setB(Set<Book17> b) {
        this.b = b;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
