package beans;

import javax.persistence.*;
import java.util.*;

/**
 * Created by user on 6/28/2017.
 */
@Entity

public class Author16b {
    @Id
    @GeneratedValue(strategy =GenerationType.AUTO )
    private int id;
    private int age;
    @OneToMany(mappedBy = "author")

    private Set<Book16b> b=new HashSet<Book16b>();

    private String firstname;

    private String lastname;

    private Date dob;
    private String bookname;

    public Author16b(){}
//    public Author16b(List<Book16b> b)
//    {
//        this.b=b;
//    }

    public Set<Book16b> getB() {
        return b;
    }

    public void setB(Set<Book16b> b) {
        this.b = b;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
