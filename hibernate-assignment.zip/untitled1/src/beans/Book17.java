package beans;

import javax.annotation.Generated;
import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by user on 6/28/2017.
 */
@Entity
public class Book17 {
    @Id
    @GeneratedValue
    private int bid;
    private String bookname;

    public Book17() {

    }

    public Book17(String bookname) {
        this.bookname = bookname;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }
}
