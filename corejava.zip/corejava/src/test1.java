
import java.util.Scanner;

public class test1 {
    static String s="";
    static int start=0,end=0;
    static Scanner sc=new Scanner(System.in);
    public static void index()
    {
    System.out.println("enter the starting index \n");
    start=sc.nextInt();
    if(start<s.length()&&start>=0)
    {
    System.out.println("enter the end index\n");
    end =sc.nextInt(); 
    }
    else
    {
        System.out.println("enter valid starting index");
        index();
    }
    }
    
    public static void main(String[] args)
    {
    System.out.println("enter the string\n");
    s=sc.nextLine();
    System.out.println(s.substring(0, 0));
    System.out.println("enter the starting and end index to replace \n");
    index();
     if(end>s.length()||start<0||end<start)
     {
         System.out.println("enter valid index\n starting index must be smaller than end index");
         index();
     }
     else if(start==end)
             {
                  System.out.println("enter the string to replace");
                  String r=sc.next();
                 s=s.substring(0,start)+r+s.substring(start+1,s.length());
                 System.out.println(s);
                // System.out.println("cannot replace the string \n end index must be greater thn starting index");
             
             }
             else
     {
         ///sahil//
    System.out.println("enter the string to replace");
    String r=sc.next();
        s=s.substring(0,start)+r+s.substring(end);
         System.out.println(s);
     }
   
}
}
