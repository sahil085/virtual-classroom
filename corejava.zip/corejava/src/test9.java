
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class test9 {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        FileInputStream fis=new FileInputStream("F://test.txt");
        StringBuilder sb=new StringBuilder(); 
       int c=0;
       while((c=fis.read())!=-1)
       {
           sb.append((char)c);
       } 
        System.out.println(sb);   
}
}
