class add
{
   public static int add(int a,int b)
   {
       return a+b;
   }
   public static double add(double a,double b)
   {
       return a+b;
   }
   public static float mul(float a,float b)
   {
       return a*b;
   }
   public static int mul(int a,int b)
   {
       return a*b; 
   }
   public static String con(String s1,String s2)
   {
       return s1+s2;
   }
   public static String con(String s1,String s2,String s3)
   {
       return s1+s2+s3;
   }
}
public class test11 {
    public static void main(String[] args) {
        int r=add.add(2, 3);
        double d=add.add(2.3,3.4);
        float f=add.mul(1.2f,3.2f);
        int m=add.mul(4,5);
        String con=add.con("radha krishna is ", "my friend");
        String con1=add.con("radha"," , krishna"," and sahil are besties");
        System.out.println("integer add : "+r+"\n double add : "+d+"\n float multiply : "+f+"\n integer multiply : "
                +m+"\n 2 strings concatenate : "+con+"\n 3 strings concatenate : "+con1+"\n");
    }
    
}
