public class test5 {
 
    public static void main(String a[]){
        int[] arr1 = {4,7,3,3,40,2};
        int[] arr2 = {3,2,12,9,40,32,4,4};
        int[] common=new int[arr1.length];
        boolean flag=true;
        for(int i=0;i<arr1.length;i++)
        {
            
            for(int k=0;k<common.length;k++)
            {
                if(arr1[i]==common[k])
                {
                    flag = false;
                    k=common.length;
                }
            }
            if(flag)
            {
            for(int j=0;j<arr2.length;j++){
                if(arr1[i]==arr2[j]){
                    common[i]=arr1[i]; 
                }
            }
            }
            flag=true;
        }
        for(int i=0;i<common.length;i++)
        {
            if(common[i]==0)
            {
                
            }
            else
            {
            System.out.println("common elements in both array are "+common[i]);
            }
        }
    }
}
