public class test6 {
    public static void checkint()
    {
         int ele[]={1,1,2,2,4,3,3,5,5,4,9};
   int twice[]=new int[ele.length];
   int uni=0;
   boolean flag=true,f=true;
   for(int i=0;i<ele.length;i++)
   {
       for(int k=0;k<twice.length;k++)
       {
           if(ele[i]==twice[k])
           {
               f=false;
               k=twice.length;
           }
       }
       if(f)
       {
       for(int j=i+1;j<ele.length;j++)
       {
       if(ele[i]==ele[j])    
       {
           twice[i]=ele[i];
           flag=false;
           j=ele.length;
       }
       }
       if(flag)
       {
           uni=ele[i]; 
       }
       }
       flag=true;
       f=true;
    }
       System.out.println("unique element in integer array is "+uni); 
    }
    public static void checkchar()
    {
        char ch[]={'a','b','d','c','c','d','a'};
        char twice[]=new char[ch.length];
        int f=0;
        char uni='@';
        boolean flag=true;
        for(int i=0;i<ch.length;i++)
        {
            char c=ch[i];
            
            for(int j=0;j<twice.length;j++)
            {
                if(c==twice[j])
                {
                    f=1;
                    
                    j=twice.length;
                }
            }
            if(f==0)
            {
                for(int k=i+1;k<ch.length;k++)
                {
                   if(c==ch[k])
                   {
                       twice[i]=c;
                       
                       flag=false;
                       k=ch.length;
                   }
                }
                if(flag)
            {
               
                uni=c;
            }
            }
            
            flag=true;
            f=0;
        }
        System.out.println("unique character in array is "+uni);
    }
   public static void main(String[] args) {
       checkint();
   checkchar();
   }
}

