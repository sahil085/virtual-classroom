public class test4 {
    public static void main(String[] args) {
        String s="Aa@12bH";
        int u=0,l=0,d=0,ch=0;
        for(int i=0;i<s.length();i++)
        {
            char c=s.charAt(i);
            if(c>64&&c<91)
            {
                u=u+1;
            }
            else if(c<123&&c>96)
            {
                l=l+1;
            }
            else if(c>47&&c<58)
            {
                d=d+1;
            }
            else
            {
                ch++;
            }
        }
        System.out.println("UPPER CASE LETTERS ARE "+u+"\n lower case letters are "+l+"\n digits are "+d+"\n special characters are "+ch);   
    }
    
}
