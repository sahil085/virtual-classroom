

public class test12 {
    public static int getdetails(int i)
    {
        return i;
    }
    public static void main(String[] args) {
      
        System.out.println("sbi bank details \n"+sbi.getdetails());
        System.out.println("boi bank details \n"+boi.getdetails());
        System.out.println("icici bank details \n"+icici.getdetails());
}
    
}
class sbi
{
    static String bankname="sbi bank";
    static int intrest=1000;
    static Object sbidetails=new Object();
    
      public  static Object getdetails()
    {
        sbidetails="bank name "+bankname+" \n intrest "+ intrest;
        
        return sbidetails;
    }
}
class boi
{
     static String bankname="boi bank";
    static int intrest=1000;
    static Object boidetails=new Object();
      public  static Object getdetails()
    {
       boidetails="bank name "+bankname+" \n intrest "+ intrest;
        
        return boidetails;
    }
}
class icici
{
     static String bankname="icici bank";
    static int intrest=1000;
    static Object icicidetails=new Object();
    public  static Object getdetails()
    {
       icicidetails="bank name "+bankname+" \n intrest "+ intrest;
        
        return icicidetails;
    }
            
}
