public class test10 {
    public enum v {
        
        radhasadan("100000"),krishnaavaas("100000");
        private v(String price)
        {
            this.price=price;
        }
        private String price;
        public String getprice()
        {
            return price;
        }
        
    }
    public test10()
            {
                int k=0;
               for(v i : v.values())
                    {
                      System.out.println("house name --> "+i+" price is --> "+i.getprice());
                      k++;
                    }
            }
//    public static int getprice(int i)
//    {
//        int price[]={29000,450000};
//      return price[i];
//    }
    public static void main(String[] args) {
        test10 t=new test10();      
}
}
